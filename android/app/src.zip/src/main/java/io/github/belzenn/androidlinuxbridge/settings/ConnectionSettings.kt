package io.github.belzenn.androidlinuxbridge.settings

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.util.UUID

data class ServerAddress(val host: String, val port: Int, val computerName: String, val distribution: String)

object ConnectionSettings {
    fun hasLocalNetworkPermission(context: Context): Boolean =
        android.os.Build.VERSION.SDK_INT < 37 || context.checkSelfPermission(
            android.Manifest.permission.ACCESS_LOCAL_NETWORK
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

    private const val PREFERENCES_NAME = "bridge_connection"
    private const val HOST_KEY = "server_host"
    private const val COMPUTER_NAME_KEY = "computer_name"
    private const val DISTRIBUTION_KEY = "distribution"
    private const val PORT_KEY = "server_port"
    private const val DEVICE_ID_KEY = "device_id"
    private const val SERVICE_NAME_KEY = "service_name"
    private const val PAIRING_PREFERENCES_NAME = "bridge_secure_pairing"
    private const val PAIRING_TOKEN_KEY = "pairing_token"

    fun loadServer(context: Context): ServerAddress? {
        val preferences = preferences(context)
        if (preferences.getString(SERVICE_NAME_KEY, null).isNullOrBlank()) {
            return null
        }
        val host = preferences.getString(HOST_KEY, null) ?: return null
        val port = preferences.getInt(PORT_KEY, 0)
        return ServerAddress(
            host, port,
            preferences.getString(COMPUTER_NAME_KEY, "") ?: "",
            preferences.getString(DISTRIBUTION_KEY, "") ?: ""
        ).takeIf {
            it.host.isNotBlank() && it.port in 1..65535
        }
    }

    fun saveServer(context: Context, host: String, port: Int, serviceName: String, computerName: String, distribution: String) {
        preferences(context).edit()
            .putString(HOST_KEY, host)
            .putInt(PORT_KEY, port)
            .putString(SERVICE_NAME_KEY, serviceName)
            .putString(COMPUTER_NAME_KEY, computerName)
            .putString(DISTRIBUTION_KEY, distribution)
            .apply()
    }

    fun preferredServiceName(context: Context): String? =
        preferences(context).getString(SERVICE_NAME_KEY, null)

    fun deviceId(context: Context): String {
        val preferences = preferences(context)
        return preferences.getString(DEVICE_ID_KEY, null) ?: UUID.randomUUID().toString().also {
            preferences.edit().putString(DEVICE_ID_KEY, it).apply()
        }
    }

    private fun trustKey(context: Context): String =
        "tls_v2:" + (preferredServiceName(context) ?: error("No selected computer"))

    fun pairingToken(context: Context): String? = trust(context)?.optString("token")
    fun pinnedKey(context: Context): String? = trust(context)?.optString("fingerprint")

    private fun trust(context: Context): org.json.JSONObject? {
        val preferences = securePreferences(context)
        // Remove the token used by the old plaintext protocol.
        if (preferences.contains(PAIRING_TOKEN_KEY)) preferences.edit().remove(PAIRING_TOKEN_KEY).commit()
        return preferences.getString(trustKey(context), null)?.let { org.json.JSONObject(it) }
    }

    fun saveTrust(context: Context, computer: String, fingerprint: String, token: String) {
        check(securePreferences(context).edit().putString("tls_v2:" + computer,
            org.json.JSONObject().put("fingerprint", fingerprint).put("token", token).toString()).commit())
    }

    fun clearPairingToken(context: Context) {
        securePreferences(context).edit().remove(trustKey(context)).remove(PAIRING_TOKEN_KEY).commit()
    }

    private fun preferences(context: Context) =
        context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)

    private fun securePreferences(context: Context) = EncryptedSharedPreferences.create(
        context,
        PAIRING_PREFERENCES_NAME,
        MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
}
